package com.example.Jenkins_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
class JenkinsDemoApplicationTests {

	@Test
	public void contextLoads() {

	}

	@Test
	public void testMain() {
		JenkinsDemoApplication.main(new String[] {});
		// You can add assertions here to verify behavior after running the main method if needed.
		assertTrue(true, "The main method executed successfully.");
	}

}
